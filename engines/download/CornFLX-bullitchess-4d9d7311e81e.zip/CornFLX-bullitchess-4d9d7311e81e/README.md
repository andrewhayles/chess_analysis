BullitChess is a chess engine supporting the UCI protocol (not fully actually). 
Always under development, but can play decent games.