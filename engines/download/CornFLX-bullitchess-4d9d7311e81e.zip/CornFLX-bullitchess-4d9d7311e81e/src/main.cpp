#include "BullitChess.h"

int main()
{
    BullitChess bc = BullitChess();
    bc.run();

    return 0;
}
