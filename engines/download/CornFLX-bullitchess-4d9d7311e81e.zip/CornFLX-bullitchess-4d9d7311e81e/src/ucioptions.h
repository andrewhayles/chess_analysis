#ifndef UCIOPTIONS_H
#define UCIOPTIONS_H

struct UciOptions
{
    int hash = 128;
};

#endif // UCIOPTIONS_H
