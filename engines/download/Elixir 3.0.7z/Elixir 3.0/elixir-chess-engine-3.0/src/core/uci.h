#pragma once

#include "board/board.h"

namespace elixir::uci {
    void uci_loop(Board &board);
}
