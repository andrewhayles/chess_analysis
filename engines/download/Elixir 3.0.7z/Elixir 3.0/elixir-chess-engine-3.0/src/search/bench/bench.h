#pragma once

namespace elixir::bench {
    void bench();
}