pub mod gen;
mod magics;
pub mod make_move;
pub mod perft;
