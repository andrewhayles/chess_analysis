Rainman chess v0.7.5 by Johnny Bigert, johnny@kth.se  (handle joppe at FICS)
FICS handle: RainmanC

Rainman is a free winboard chess engine.


INSTALL:
--------

Unzip the files to c:\program files (or change the paths in the .bat and .ini files)
and the program will be placed in c:\program files\rainman_v075.

- Settings are available in rainman.ini
- Run winboard.bat to play Rainman locally at your PC.
- Run fics.bat to let Rainman play other people at the free internet chess server (FICS).



Visit http:/www.nada.kth.se/~johnny/chess_comp.html for details and updates.

Good luck

  / Johnny Bigert, 25 July, 2003