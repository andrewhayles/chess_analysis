Achillees developed by 'tempate' aka Daniel Diaz

*updated* 2021-01-26 => added amdfam10 compilation
compiled  2020-10-10
last commit 2019-10-14

get source => https://github.com/Tempate/Achillees

Last change was a time management fix, especially for
repeating time controls, probably because of some
report from CCRL during the test of the release version
compiled by linuxchess.

I did a couple of test games at 120s/40 and indeed it
uses a bit more time especially in the beginning
and the end of a move session.

I took the freedom to rename it to version 1.01

Guenther

