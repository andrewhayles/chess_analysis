Anaconda 2.0.7 Beta UCI (2005-05-06)
authors: Frank Schneider + Kai Skibbe (DEU)

Anaconda was privately sent to RWBC in 2005-05 and participated in the 6th and 7th (last) edition
of the RWBC engine tournaments between 2005 and 2007 with great success.

https://rwbc-chess.de/all.htm

After cleaning up my archives some months ago I decided to offer it to the public after more than
20 years. (regrettably my attempts to contact the original authors failed though - but I guess
they will forgive me after those two decades of Anaconda living a private life on my harddisks.
It would be too sad if it would fall into total oblivion otherwise, there sure will be collectors
and testers, who will appreciate it even nowadays)


Guenther Simon
Regensburg, 2025-07-01

