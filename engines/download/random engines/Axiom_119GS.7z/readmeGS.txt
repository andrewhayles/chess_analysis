Axiom 1.1.9: avx2/bmi2 compilation on Ryzen7 5700G WIN11Pro
author: Sindre Wolden (NOR)

compiled for .Net8 with .Net SDK 9.0.100 in 2025-03-14

sources => https://github.com/InternetHamburger/Axiom

note: missing 'isready' command is fixed since version 1.0.0

Guenther Simon
Regensburg, 2025-03-15
