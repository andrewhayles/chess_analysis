#pragma once

#include "search.hpp"

namespace search::bench {

void run(searcher& searcher, u32 depth);

}