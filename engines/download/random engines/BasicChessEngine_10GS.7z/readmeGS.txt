BasicChessEngine 1.0.0 GS (old/bmi2 compilations)
author: Alexander Wimmer (FRA)

compiled: 2024-01-11 with GCC 13.2.0 in Msys2

https://github.com/Checkmate6659/basic-chess-engine


Guenther Simon
Regensburg, 2024-01-12
