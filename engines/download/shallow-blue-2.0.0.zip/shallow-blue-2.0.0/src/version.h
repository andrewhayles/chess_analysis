#ifndef VERSION_H
#define VERSION_H

#define VER_MAJ 2
#define VER_MIN 0
#define VER_PATCH 0

#endif
