
      @@@@@@   @@   @@   @@@@@@   @@   @@      @      @@@@@     @@@@
     @@        @@   @@   @@       @@@  @@     @@@     @@   @@   @@  @
     @@        @@   @@   @@       @@@@ @@    @@ @@    @@   @@   @@  @@
     @@        @@@@@@@   @@@@@    @@ @@@@   @@   @@   @@   @@   @@  @@
     @@        @@   @@   @@       @@  @@@   @@@@@@@   @@@@@     @@  @@
     @@        @@   @@   @@       @@   @@   @@   @@   @@   @@   @@  @
      @@@@@@   @@   @@   @@@@@@   @@   @@   @@   @@   @@   @@   @@@@


Documentation for Windows version of Chenard, a chess program by Don Cross.

NOTE:  If you have web access, check in on the following URL every now and
       then to see if there are newer versions of Chenard.  You can tell
       which version you have by looking in Chenard's menu Help|About.

http://cosinekitty.com/chenard

------------------------------------------------------------------------------

What is Chenard?
================
Chenard is a chess program that I have been working on since April 1993.
Chenard comes in different versions.  This version (also known as WinChenard)
runs under Windows 7 and higher.

The Chenard program is freely distributable.
You may give copies to anyone anywhere in the world, so long as you distribute
both WINCHEN.EXE and this text file unmodified and in their entirety.

The C++ source code for Chenard is available on GitHub:
https://github.com/cosinekitty/chenard

The source code is copyrighted, but I (Don Cross) allow anyone to use it
freely for non-commercial uses, and especially for non-profit educational uses.

If you wish to distribute versions of the Chenard program or its source code
which have been modified in any way, you must obtain express written permission
from me, Don Cross.  Please contact me by email at:

   cosinekitty@gmail.com

------------------------------------------------------------------------------

Instructions for installing Chenard
===================================
I recommend that you create a directory for Chenard, then unzip the file
WINCHEN.ZIP into it.  You will then have the following files:

    winchen.exe         -  The Chenard executable itself
    chenard_readme.txt  -  This file

If you are running 64-bit Windows, you can try out winchen64.zip instead,
which contains winchen64.exe.  This program has exactly the same features 
as the regular (32-bit) winchen.exe, but you will find that it is roughly
25% faster on the same hardware.  However, winchen64 will not work on 
32-bit Windows, so if you aren't sure what you have, download the regular 
WINCHEN.ZIP, because it will work on both 32-bit and 64-bit Windows.

Note 1: 
      These files are enough for Chenard to play chess, but you can also
      optionally download the file CHENWAV.ZIP from the Chenard web page
      to give Chenard the ability to speak the move notation through your
      sound card (see the View|Speak option later in this document).
      Put CHENWAV.ZIP in the same directory that you installed Chenard in,
      then unzip it to obtain the necessary *.WAV files.

Note 2:
      There are also some endgame databases you can download in ENDGAME.ZIP.
      They help Chenard play much better in certain endgame positions.
      Download and unzip ENDGAME.ZIP in the same directory as WINCHEN.EXE
      (or WINCHEN64.EXE).  This is a rather large zip file (about 4MB),
      and Chenard will work without them, so that is why I provide them as
      a separate download.

After installing the Chenard files, you can create an icon in Windows
to run the program.  For example, to make a shortcut on your desktop, click
the right mouse button once while holding the mouse over a blank space on
the desktop.  Then choose "New", then "Shortcut".  Use the Browse button
to locate the subdirectory where you just put all of the Chenard distribution
files, and in it select the file WINCHEN.EXE with the mouse.  Continue with
the process by clicking the Next button, optionally giving the shortcut the name
"Chenard".  Once you are done, you will be able to double click on the
shortcut icon and run Chenard.

------------------------------------------------------------------------------

How to run Chenard
==================
When you first run Chenard, a dialog box appears which asks who should
play White and who should play Black.  By default, Chenard randomly assigns
one color to you (Human) and one to itself (Computer), with equal likelihood.

However, you can play Chenard against itself if you like -- just set both
White and Black to "Computer" and watch the fight begin!  It's fun to
set one side to think for a much larger amount of time than the other,
virtually guaranteeing its overwhelming victory.

The final possibility is to set both White and Black to "Human" and just
use the program as a passive chess board which enforces legal moves.
(In this case, the View|Rotate Board command may be useful).

You can adjust Chenard's playing strength by modifying the amount of time it
spends thinking about each move.  The "think time" appears to the right of
each radio button labeled "Computer" in the opening dialog box.
You should enter a time expressed in seconds.  I recommend starting
out somewhere around 1 to 5 seconds.  If this seems too easy for you to beat,
then increase the time to your liking.  Starting in version 1.030, the
think time may be a fractional number of seconds, with the minimum allowed
value being 0.1 seconds.

Menu commands available in Chenard
==================================
File|New        - throw this game away and start a new one
File|Open       - load a game from a file
File|Save       - save the current state of the game to a file
File|Save As    - save to another filename
File|Exit       - quits out of the Chenard program

Edit|Clear Board  -  removes all pieces from the board except the kings

Edit|Edit Mode
    Toggles edit mode.  When on, clicking on a square with the left
    mouse button will bring up a dialog box which lets you change the
    contents of the square to anything you like.  When you choose "king",
    the specified color king is moved (not replicated!) to the given square.
    Clicking on a square with the right mouse button while in edit mode
    repeats this last edit action to the specified square.  You must turn
    edit mode off to resume normal play.

Edit|Copy Game Listing
    This command copies a text listing of the moves which have been
    played so far into the Windows clipboard.  Then, you will be able
    to paste the game listing into Notepad, your favorite word processor,
    etc.  Then you could print the game listing or save it as a text file.

Edit|Undo Move
    Cancels the last whole move (pair of turns) in the game, so that you
    can try a different move.  You can repeat this action as many times
    as you want to back up toward the beginning of the game.

Edit|Redo Move
    Cancels one Undo action every time it is performed, moving forward
    in the game by a whole move (pair of turns).

View|Freshen
    Try this command if it looks like Chenard has not rendered the whole
    display correctly.  Theoretically, you should never have to do this.

View|Rotate
    By default, when one player is human and the other is the computer,
    Chenard shows the human side toward the bottom of the screen and
    the computer's side toward the top of the screen.  At any time,
    you can toggle the orientation of the view by selecting this menu
    command, or pressing Ctrl+R.  This is especially useful if you are
    playing Chenard against another computer program, because you can
    then see the board from the same point of view in both programs.

View|Speak moves through sound card (disabled by default)
    NOTE:  The WAV files necessary for this command are now distributed
    separately from Chenard, simply because they are rather large.
    If you want to use View|Speak, you will need to visit the Chenard web page,
    download the file called "chenwav.zip" and unzip it into the same directory
    where you installed Chenard.

    This option requires a sound card in your computer which can handle
    8-bit monaural PCM WAV files sampled at 11.025 kHz.  Most any sound
    card these days should be able handle this.  When this option is enabled,
    the computer will speak (using recordings of the author's voice)
    move notation through the sound card after each move is played.

View|Board Size
    Has three different choices allowed: Small(default), Medium, and Large.
    Small will always make the graphics look crispest and nicest, but
    Medium and Large are provided in case you want to make the board display
    more legible from a distance.

View|Piece Style
    Allows you to choose from one of three different styles for the graphics
    of the chess pieces on the board:

         Original   by   Don Cross
         Tilburg    by   Eric Schiller & William Cone
         Skak       by   Egon Madsen

    If you are interested in the topic of computer chess fonts, visit
    Alastair Scott's web page at:

         http://www.users.dircon.co.uk/~amscott/home.htm

    Alastair was the one who contacted me and supplied me with the Tilburg
    and Skak chess fonts, and Chenard has looked much better ever since!

Game|Force Move
    Use this command whenever it is Chenard's turn to move and you
    are losing your patience.  This command will force the computer to
    immediately make whatever move it currently thinks is best.

Game|Edit Think Times
    Allows you to edit the maximum amount of time that the computer player(s)
    spend thinking about each move they make.  Note that editing the think
    time of a computer player while it is thinking about a move will have no
    effect on the current move, but will kick in immediately after that.
    See also: Game|Force Move.

Game|Allow Computer to Resign
    When enabled (checked), this option allows the computer to resign
    when it decides that it will inevitably lose.  Turn this option off
    (unchecked) if you want the computer to play to the "bloody end"
    no matter how badly it is losing.

Game|Tactical Benchmark
    This command is probably not of much interest to most users.
    It runs a series of pre-programmed tests to determine how efficient
    my chess engine is on the current computer.  You can compare your
    computer's efficiency to that of the author's 100 MHz Pentium machine.
    This test can take a long time (6 minutes on my machine), and once
    started, the only way you can stop it is to close the whole Chenard
    program.

Help|About
    Tells you the version of Chenard, my email address, and Chenard's
    address on the World Wide Web.  Please feel free to send me any
    questions or comments relating to Chenard.  Even though it is a free
    program, I do try to support it as much as possible because I want
    people to enjoy using it.  Again, here's how to contact me:

         email:   cosinekitty {at} hotmail {dot} com
         web:     http://cosinekitty.com/chenard

Help|visit Chenard web page
    Launches the Chenard web page in your default browser:
    http://cosinekitty.com/chenard/

Why did I write Chenard?
========================
The short answer to this question is: for fun!  Chenard is actually the
second chess program I have written.  The first one (called Chester) was
a success in that it could play a reasonable game of chess, but I knew
that the code was never going to run on anything but MS-DOS due to a lot of
machine dependencies (including hand-optimized assembly code).  I decided
that I wanted to pursue chess programming as a long-term hobby, and that
meant that I should design a chess engine to be portable to different
operating systems from the ground up.  This way, no matter what direction
the computer industry took in the years to come, I would have an easy way
to keep Chenard "alive".

So I had a real ball designing, implementing, and refining Chenard into
the program it is today.  But then I ran into a problem: I had worked
so hard creating this thing, but very few people I knew seemed interested in
actually *using* it.  Kind of a letdown...

But then the World Wide Web happened!  I realized that instead of bugging
my friends to play my program, I could just cast a larger net; surely
*someone* out there in the world would get some use out of it.  Chenard
was one of the first things I put on my web site.

                    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~


I hope you enjoy using Chenard!
